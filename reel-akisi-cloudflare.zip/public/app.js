let reels = [];
let current = Number(localStorage.getItem("reelIndex") || 0);

const $ = id => document.getElementById(id);

async function loadReels() {
  const res = await fetch("/api/reels");
  const data = await res.json();
  reels = data.reels || [];

  if (!reels.length) {
    $("empty").classList.remove("hidden");
    $("player").classList.add("hidden");
    $("counter").textContent = "0 / 0";
    $("prev").disabled = true;
    $("next").disabled = true;
    return;
  }

  $("empty").classList.add("hidden");
  $("player").classList.remove("hidden");
  current = Math.min(Math.max(current, 0), reels.length - 1);
  render();
}

function render() {
  const reel = reels[current];
  $("counter").textContent = `${current + 1} / ${reels.length}`;
  $("prev").disabled = current === 0;
  $("next").disabled = current === reels.length - 1;
  localStorage.setItem("reelIndex", String(current));

  $("error").classList.add("hidden");
  $("embed").innerHTML = `
    <blockquote class="instagram-media"
      data-instgrm-permalink="${reel.reel_url}"
      data-instgrm-version="14"
      style="background:#000; border:0; margin:0; max-width:540px; width:100%;">
    </blockquote>`;

  if (window.instgrm?.Embeds) {
    window.instgrm.Embeds.process();
  } else {
    setTimeout(() => window.instgrm?.Embeds?.process(), 500);
  }
}

$("prev").addEventListener("click", () => {
  if (current > 0) { current--; render(); }
});

$("next").addEventListener("click", () => {
  if (current < reels.length - 1) { current++; render(); }
});

loadReels().catch(() => {
  $("empty").classList.remove("hidden");
  $("empty").innerHTML = "<h1>Bağlantı hatası</h1><p>Liste yüklenemedi.</p>";
});