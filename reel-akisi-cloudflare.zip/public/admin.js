const $ = id => document.getElementById(id);
let currentReels = [];

const today = new Date().toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" });
$("date").value = today;

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "content-type": "application/json", ...(options.headers || {}) }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "İşlem başarısız.");
  return data;
}

async function login() {
  try {
    await api("/api/admin/login", {
      method: "POST",
      body: JSON.stringify({ password: $("password").value })
    });
    $("loginCard").classList.add("hidden");
    $("panel").classList.remove("hidden");
    await loadList();
  } catch (e) {
    $("loginMsg").textContent = e.message;
  }
}

async function loadList() {
  try {
    const data = await api(`/api/admin/reels?date=${encodeURIComponent($("date").value)}`);
    currentReels = data.reels || [];
    renderList();
  } catch (e) {
    $("msg").textContent = e.message;
  }
}

function renderList() {
  $("list").innerHTML = "";
  currentReels.forEach((r, i) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="reel-item">
        <span class="reel-url" title="${escapeHtml(r.reel_url)}">${escapeHtml(r.reel_url)}</span>
        <button class="small-btn" data-up="${i}">↑</button>
        <button class="small-btn" data-down="${i}">↓</button>
        <button class="small-btn" data-delete="${r.id}">Sil</button>
      </div>`;
    $("list").appendChild(li);
  });

  $("list").querySelectorAll("[data-up]").forEach(btn => btn.onclick = () => move(Number(btn.dataset.up), -1));
  $("list").querySelectorAll("[data-down]").forEach(btn => btn.onclick = () => move(Number(btn.dataset.down), 1));
  $("list").querySelectorAll("[data-delete]").forEach(btn => btn.onclick = () => removeReel(Number(btn.dataset.delete)));
}

async function move(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= currentReels.length) return;
  [currentReels[index], currentReels[target]] = [currentReels[target], currentReels[index]];
  await api("/api/admin/reels/reorder", {
    method: "PUT",
    body: JSON.stringify({ ids: currentReels.map(r => r.id) })
  });
  renderList();
}

async function removeReel(id) {
  if (!confirm("Bu Reel silinsin mi?")) return;
  await api(`/api/admin/reels/${id}`, { method: "DELETE" });
  await loadList();
}

async function addReels() {
  const urls = $("urls").value.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  try {
    const data = await api("/api/admin/reels", {
      method: "POST",
      body: JSON.stringify({ date: $("date").value, urls })
    });
    $("urls").value = "";
    $("msg").textContent = `${data.added} Reel eklendi.`;
    await loadList();
  } catch (e) {
    $("msg").textContent = e.message;
  }
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

$("login").onclick = login;
$("password").addEventListener("keydown", e => { if (e.key === "Enter") login(); });
$("load").onclick = loadList;
$("add").onclick = addReels;
$("date").addEventListener("change", loadList);
$("logout").onclick = async () => {
  await api("/api/admin/logout", { method: "POST" });
  location.reload();
};