# Reel Akışı

Cloudflare Workers + D1 üzerinde çalışan, günlük Instagram Reel linklerini yönetmeye yönelik basit uygulama.

## Kurulum

1. Cloudflare'da bir D1 database oluştur:
   - Database adı: `reel-akisi-db`
2. D1 database ID'sini `wrangler.toml` içindeki `database_id` alanına yaz.
3. Admin şifresini Cloudflare Worker Secret olarak ekle:
   - Secret name: `ADMIN_PASSWORD`
4. Migration çalıştır:
   `npx wrangler d1 migrations apply DB`
5. Deploy:
   `npm install`
   `npm run deploy`

## Cloudflare GitHub Build ayarları

- Build command: `npm run deploy`
- Deploy command: `npx wrangler deploy`
- Gerekirse `CLOUDFLARE_API_TOKEN` / ilgili Cloudflare Git entegrasyonu kullanılmalı.

Not: Instagram embed içeriği Instagram'ın kendi erişim ve embed kurallarına tabidir. Bu proje Instagram engellerini aşmak için proxy/scraping kullanmaz.
