const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" }
  });

function isInstagramReelUrl(value) {
  try {
    const u = new URL(value);
    const host = u.hostname.toLowerCase();
    return (host === "instagram.com" || host === "www.instagram.com") &&
      /^\/reel\/[^/?#]+\/?$/i.test(u.pathname);
  } catch {
    return false;
  }
}

async function sha256(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}

async function requireAdmin(request, env) {
  const cookie = request.headers.get("Cookie") || "";
  const match = cookie.match(/reel_admin=([^;]+)/);
  if (!match) return false;

  const tokenHash = await sha256(match[1]);
  const row = await env.DB.prepare(
    "SELECT token_hash, expires_at FROM admin_sessions WHERE token_hash = ?"
  ).bind(tokenHash).first();

  if (!row || row.expires_at < Math.floor(Date.now() / 1000)) return false;
  return true;
}

function todayTR() {
  const d = new Date();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Istanbul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(d);
  const get = type => parts.find(p => p.type === type)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

async function handleApi(request, env, url) {
  if (url.pathname === "/api/reels" && request.method === "GET") {
    const date = url.searchParams.get("date") || todayTR();
    const result = await env.DB.prepare(
      "SELECT id, reel_url, reel_date, sort_order FROM reels WHERE reel_date = ? ORDER BY sort_order ASC, id ASC"
    ).bind(date).all();
    return json({ date, reels: result.results });
  }

  if (url.pathname === "/api/admin/login" && request.method === "POST") {
    const body = await request.json().catch(() => null);
    if (!body?.password || !env.ADMIN_PASSWORD) return json({ error: "Giriş bilgileri hatalı." }, 400);
    if (body.password !== env.ADMIN_PASSWORD) return json({ error: "Şifre yanlış." }, 401);

    const token = crypto.randomUUID() + crypto.randomUUID();
    const tokenHash = await sha256(token);
    const expiresAt = Math.floor(Date.now() / 1000) + 60 * 60 * 12;

    await env.DB.prepare(
      "INSERT INTO admin_sessions (token_hash, expires_at) VALUES (?, ?)"
    ).bind(tokenHash, expiresAt).run();

    return new Response(JSON.stringify({ ok: true }), {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "Set-Cookie": `reel_admin=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${60 * 60 * 12}`
      }
    });
  }

  if (url.pathname === "/api/admin/logout" && request.method === "POST") {
    const cookie = request.headers.get("Cookie") || "";
    const match = cookie.match(/reel_admin=([^;]+)/);
    if (match) {
      await env.DB.prepare("DELETE FROM admin_sessions WHERE token_hash = ?")
        .bind(await sha256(match[1])).run();
    }
    return new Response(null, {
      status: 204,
      headers: { "Set-Cookie": "reel_admin=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0" }
    });
  }

  if (!url.pathname.startsWith("/api/admin/")) return null;

  if (!(await requireAdmin(request, env))) {
    return json({ error: "Yetkisiz." }, 401);
  }

  if (url.pathname === "/api/admin/reels" && request.method === "POST") {
    const body = await request.json().catch(() => null);
    const date = body?.date;
    const urls = Array.isArray(body?.urls) ? body.urls : [];

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date || "")) {
      return json({ error: "Geçerli bir tarih girin." }, 400);
    }

    const clean = [...new Set(urls.map(v => String(v).trim()).filter(isInstagramReelUrl))];
    if (!clean.length) return json({ error: "Geçerli Instagram Reel linki bulunamadı." }, 400);

    const maxRow = await env.DB.prepare(
      "SELECT COALESCE(MAX(sort_order), -1) AS max_order FROM reels WHERE reel_date = ?"
    ).bind(date).first();
    let order = Number(maxRow?.max_order ?? -1) + 1;

    const stmt = env.DB.prepare(
      "INSERT INTO reels (reel_url, reel_date, sort_order) VALUES (?, ?, ?)"
    );

    const batch = clean.map(reel => stmt.bind(reel, date, order++));
    await env.DB.batch(batch);

    return json({ ok: true, added: clean.length });
  }

  const deleteMatch = url.pathname.match(/^\/api\/admin\/reels\/(\d+)$/);
  if (deleteMatch && request.method === "DELETE") {
    await env.DB.prepare("DELETE FROM reels WHERE id = ?")
      .bind(Number(deleteMatch[1])).run();
    return json({ ok: true });
  }

  if (url.pathname === "/api/admin/reels/reorder" && request.method === "PUT") {
    const body = await request.json().catch(() => null);
    const ids = Array.isArray(body?.ids) ? body.ids.map(Number).filter(Number.isInteger) : [];
    if (!ids.length) return json({ error: "Liste boş." }, 400);

    const statements = ids.map((id, index) =>
      env.DB.prepare("UPDATE reels SET sort_order = ? WHERE id = ?").bind(index, id)
    );
    await env.DB.batch(statements);
    return json({ ok: true });
  }

  if (url.pathname === "/api/admin/reels" && request.method === "GET") {
    const date = url.searchParams.get("date") || todayTR();
    const result = await env.DB.prepare(
      "SELECT id, reel_url, reel_date, sort_order, created_at FROM reels WHERE reel_date = ? ORDER BY sort_order ASC, id ASC"
    ).bind(date).all();
    return json({ date, reels: result.results });
  }

  return json({ error: "Bulunamadı." }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      try {
        const response = await handleApi(request, env, url);
        if (response) return response;
      } catch (error) {
        return json({ error: "Sunucu hatası." }, 500);
      }
    }

    return env.ASSETS.fetch(request);
  }
};